function level3NormWalls(){
    const nWall1 = {
        x : 152,
        y : 262,
        width : 10,
        height : 100,
    }
    return [nWall1];
}