function level5NormWalls(){
    const nWall1 = {
        x : 152,
        y : 252,
        width : 145,
        height : 5,
    }
    return [nWall1];
}