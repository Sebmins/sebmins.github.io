function level2NormWalls(){
    const nWall1 = {
        x : 105,
        y : 240,
        width : 105,
        height : 5,
    }
    return [nWall1];
}