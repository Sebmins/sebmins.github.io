// LOAD BG IMAGE
const BG_IMG_LEVEL1 = new Image();
BG_IMG_LEVEL1.src = "img/Level1BackgroundHD.png";

const BG_IMG_LEVEL2 = new Image();
BG_IMG_LEVEL2.src = "img/Level2Background.png";

const BG_IMG_LEVEL3 = new Image();
BG_IMG_LEVEL3.src = "img/Level3Background.png";

const BG_IMG_LEVEL4 = new Image();
BG_IMG_LEVEL4.src = "img/Level4Background.png";

const BG_IMG_LEVEL5 = new Image();
BG_IMG_LEVEL5.src = "img/Level5Background.png";

const BG_IMG_LEVEL6 = new Image();
BG_IMG_LEVEL6.src = "img/Level6Background.png";

const PUCK = new Image();
PUCK.src = "img/puckwithshadow.png";

const PUCK_SHADOW = new Image();
PUCK_SHADOW.src = "img/shadow.png"

const LIFE_IMG = new Image();
LIFE_IMG.src = "img/life.png";

