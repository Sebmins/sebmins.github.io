function level4RedWalls(){
    const nWall1 = {
        x : 142,
        y : 242,
        width : 145,
        height : 5,
    }
    return [nWall1];
}